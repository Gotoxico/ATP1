#include <stdio.h>
#include <string.h>
int main(){
    int N, K, mesmo;
    char S[20], idioma[20];
    printf("Digite N: ");
    scanf("%d", &N);

    for(int k=0; k<N; k++){
        printf("Digite K: ");
        scanf("%d\n", &K);
        mesmo=1;
        printf("Digite idioma: ");
        gets(idioma);
        for(int i=1; i<K; i++){
            gets(S);
            if(strcmp(idioma, S)){
                mesmo=0;
            }
            else{}
        }
        if(mesmo==1){
            printf("%s\n", idioma);}
        else{
            printf("ingles\n");}
    }
    return 0;
}